﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmEncode : Form
    {
        public Image myImage;
        public string fileLocation;
        public frmEncode()
        {
            InitializeComponent();
        }

        private void pnlDragDrop_DragDrop(object sender, DragEventArgs e)
        {
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            pictureBox1.ImageLocation = files[0];
            pnlPreviewEncode.Visible = true;
            pnlSendReport.Visible = false;
            pnlPreviewEncode.Dock = DockStyle.Fill;
        }

        private void pnlDragDrop_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.All;
        }

        private void frmEncode_Load(object sender, EventArgs e)
        {
            pnlSendReport.Dock = DockStyle.Fill;
            pnlSendReport.BringToFront();
            frmDecodeSteg form2 = new frmDecodeSteg();
            form2.Show();
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.ShowDialog();

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                string fileName;
                fileName = dlg.FileName;
                pictureBox1.ImageLocation = fileName;
                pnlPreviewEncode.Visible = true;
                pnlSendReport.Visible = false;
                pnlPreviewEncode.Dock = DockStyle.Fill;

            }
        }

        private void btnScreenshot_Click(object sender, EventArgs e)
        {
            this.Hide();
            System.Threading.Thread.Sleep(1000);
            SendKeys.Send("{PRTSC}");
            myImage = Clipboard.GetImage();
            pictureBox1.Image = myImage;
            this.Show();
            pnlPreviewEncode.Visible = true;
            pnlSendReport.Visible = false;
            pnlPreviewEncode.Dock = DockStyle.Fill;
        }

        private void btnNo_Click(object sender, EventArgs e)
        {
            pnlPreviewEncode.Visible = false;
            pnlSendReport.Visible = true;
            pnlSendReport.Dock = DockStyle.Fill;
        }

        private void btnYes_Click(object sender, EventArgs e)
        {
            Bitmap img = new Bitmap(myImage);

            for (int i = 0; i < img.Width; i++) 
            {
                for (int j = 0; j < img.Height; j++) 
                {
                    Color pixel = img.GetPixel(i, j);

                    if (i < 1 && j < lblDragDrop.Text.Length)
                    {
                        Console.WriteLine("R = [" + i + "][" + j + "] = " + pixel.R);
                        Console.WriteLine("G = [" + i + "][" + j + "] = " + pixel.G);
                        Console.WriteLine("B = [" + i + "][" + j + "] = " + pixel.B);

                        char letter = Convert.ToChar(lblDragDrop.Text.Substring(j, 1));
                        int value = Convert.ToInt32(letter);
                        Console.WriteLine("letter : " + letter + " value: " + pixel.B);

                        img.SetPixel(i, j, Color.FromArgb(pixel.R, pixel.G, value));
                    }
                }
            }
            SaveFileDialog saveFile = new SaveFileDialog();
            saveFile.Filter = "Image Files (*.png) | *.png;";
            //Edit this
            saveFile.InitialDirectory = @"C:\Users\omioc\Desktop";

            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                fileLocation = saveFile.FileName.ToString();
                pictureBox1.ImageLocation = fileLocation;
                img.Save(fileLocation);
            }
        }


    }
}
