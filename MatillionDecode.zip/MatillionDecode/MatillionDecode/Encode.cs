using System.Drawing;
using System.Drawing.Text;

namespace MatillionDecode
{
    public partial class Encode : Form
    {
        public Encode()
        {
            InitializeComponent();
        }

        private void pnlDragDrop_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnlDragDrop_DragDrop(object sender, DragEventArgs e)
        {
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            pictureBox1.ImageLocation = files[0];
            pnlPreviewEncode.Visible = true;
            pnlSendReport.Visible = false;
            pnlPreviewEncode.Dock = DockStyle.Fill;
        }

        private void pnlDragDrop_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.All;
        }

        private void btnScreenshot_Click(object sender, EventArgs e)
        {
            this.Hide();
            System.Threading.Thread.Sleep(1000);
            SendKeys.Send("{PRTSC}");
            Image myImage = Clipboard.GetImage();
            pictureBox1.Image = myImage;
            this.Show();
            pnlPreviewEncode.Visible = true;
            pnlSendReport.Visible = false;
            pnlPreviewEncode.Dock = DockStyle.Fill;
        }

        private void Encode_Load(object sender, EventArgs e)
        {
            pnlSendReport.Dock= DockStyle.Fill;
            pnlSendReport.BringToFront(); 
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnNo_Click(object sender, EventArgs e)
        {
            pnlPreviewEncode.Visible = false;
            pnlSendReport.Visible = true;
            pnlSendReport.Dock = DockStyle.Fill;
        }

        private void lblDragDrop_Click(object sender, EventArgs e)
        {

        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.ShowDialog();

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                string fileName;
                fileName = dlg.FileName;
                pictureBox1.ImageLocation = fileName;
                pnlPreviewEncode.Visible = true;
                pnlSendReport.Visible = false;
                pnlPreviewEncode.Dock = DockStyle.Fill;

            }
        }
    }
}