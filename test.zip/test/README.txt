README

1) Start on the encoding form
2) Choose any of the chosen options to submit an image
3) Click yes to submit
4) Save your new image with another name (such as screenshotEncoded.png)
5) Move to the decoding form
6) Select the saved image with the name you've chosen (i.e. screenshotEncoded.png)